import UIKit

class PhotosViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
   
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBAction func back(_ sender: Any) {
        
    }
    var photos = ["Rectangle 68","Rectangle 24","Rectangle 69","Rectangle 108","Rectangle 109","a"]

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "photosCell", for: indexPath)
        
        // Access the UILabel using its tag
        if let label = cell.viewWithTag(1) as? UILabel {
            label.text = photos[indexPath.row] // Set album name
        }
        
        return cell
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        collectionView.dataSource = self
        collectionView.delegate = self
    
        // Reload the collection view to reflect the data
        collectionView.reloadData()

    }
 
}
