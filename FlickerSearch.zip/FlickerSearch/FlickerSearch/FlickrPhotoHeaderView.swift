//
//  FlickrPhotoHeaderView.swift
//  FlickerSearch
//
//  Created by Student on 14/09/24.
//  Copyright © 2024 Student. All rights reserved.
//

import UIKit

class FlickrPhotoHeaderView: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
