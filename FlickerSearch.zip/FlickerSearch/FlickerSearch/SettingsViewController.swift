//
//  SettingsViewController.swift
//  FlickerSearch
//
//  Created by Student on 25/09/24.
//  Copyright © 2024 Student. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    
    
    @IBOutlet weak var tv: UITableView!
    
    @IBAction func back(_ sender: Any) {
        
    }
    // Settings options with (title, switch state, image name)
    let settingsOptions = [
        ("Notifications", true, "notifications_icon"),
        ("Dark mode", false, "dark_mode_icon"),
        ("Intelligent Classification", true, "intelligent_classification_icon"),
        ("Recently deleted", false, "recently_deleted_icon"),
        ("Auto Rotate", true, "auto_rotate_icon"),
        ("QR Code", false, "qr_code_icon"),
        ("About App", false, "about_app_icon"),
        ("Help", false, "help_icon")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tv.delegate = self
        tv.dataSource = self
    }
}

extension SettingsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SettingsCell", for: indexPath)
        
        let setting = settingsOptions[indexPath.row]
        cell.textLabel?.text = setting.0
        cell.imageView?.image = UIImage(named: setting.2) // Assign the image
        
        if setting.0.contains("Notifications") || setting.0.contains("Dark mode") ||
            setting.0.contains("Intelligent Classification") || setting.0.contains("Recently deleted") || setting.0.contains("Auto Rotate") {
            let switchView = UISwitch(frame: .zero)
            switchView.setOn(setting.1, animated: true)
            switchView.tag = indexPath.row
            switchView.addTarget(self, action: #selector(switchChanged(_:)), for: .valueChanged)
            cell.accessoryView = switchView
        } else {
            cell.accessoryType = .disclosureIndicator
        }
        
        return cell
    }
    
    @objc func switchChanged(_ sender: UISwitch!) {
        let option = settingsOptions[sender.tag]
        print("\(option.0) is now \(sender.isOn ? "On" : "Off")")
        
        // Add code to handle the changes (e.g., save the switch state)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let option = settingsOptions[indexPath.row].0
        
        if option == "QR Code" {
            // Navigate to QR code screen
        } else if option == "About App" {
            // Navigate to About App screen
        } else if option == "Help" {
            // Navigate to Help screen
        }
    }
}
