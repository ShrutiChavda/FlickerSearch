//
//  AlbumCollectionViewCell.swift
//  FlickerSearch
//
//  Created by Student on 16/09/24.
//  Copyright © 2024 Student. All rights reserved.
//

import UIKit

class AlbumCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
