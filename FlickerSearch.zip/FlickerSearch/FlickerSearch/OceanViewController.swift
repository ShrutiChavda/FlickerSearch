    //
    //  OceanViewController.swift
    //  FlickerSearch
    //
    //  Created by Student on 24/09/24.
    //  Copyright © 2024 Student. All rights reserved.
    //

    import UIKit

    class OceanViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate{

        
        @IBOutlet weak var collectionView: UICollectionView!
        
        var photos = ["Rectangle 116","Rectangle 24","Rectangle 109","Rectangle 111","Rectangle 112","Rectangle 115"]
        
        
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return photos.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "oceanCell", for: indexPath)
            
            // Access the UIImageView using its tag
            if let imageView = cell.viewWithTag(1) as? UIImageView {
                imageView.image = UIImage(named: photos[indexPath.row]) // Set album image
            }
            
            return cell
        }
        
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            collectionView.dataSource = self
            collectionView.delegate = self
            
            // Reload the collection view to reflect the data
            collectionView.reloadData()
            
        }
        
    }

