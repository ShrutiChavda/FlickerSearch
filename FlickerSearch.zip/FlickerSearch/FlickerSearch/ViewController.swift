import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var addNewAlbum: UIButton!
    
    var albums = ["Ocean", "Mountain", "Birthday", "Friends", "Family"]
    var albumImages = ["Rectangle 112", "Rectangle 24", "birthday", "Friends", "Family"]
    var albumTypes = ["jpg", "png", "gif", "jpeg", "bmp"]
    var albumSizes = [1024, 2048, 512, 768, 1280] // Dummy sizes in KB
    var albumDatesModified = [Date(), Date().addingTimeInterval(-86400), Date().addingTimeInterval(-172800), Date().addingTimeInterval(-604800), Date().addingTimeInterval(-2592000)] // Last modified dates
    var albumDatesCreated = [Date().addingTimeInterval(-2592000), Date().addingTimeInterval(-604800), Date(), Date().addingTimeInterval(-86400), Date().addingTimeInterval(-172800)] // Created dates
    var albumHeights = [500, 400, 300, 600, 350] // Heights in pixels
    var albumWidths = [700, 800, 600, 900, 450] // Widths in pixels
    

    // Method to present the sorting options
    @IBAction func openSortDialog(_ sender: UIButton) {
        let sortController = UIAlertController(title: "Sort by", message: nil, preferredStyle: .actionSheet)
        
        let sortByName = UIAlertAction(title: "Name", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .name)
        }
        
        let sortByType = UIAlertAction(title: "Type", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .type)
        }
        
        let sortBySize = UIAlertAction(title: "Size", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .size)
        }
        
        let sortByDateModified = UIAlertAction(title: "Date Modified", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .dateModified)
        }
        
        let sortByDateCreated = UIAlertAction(title: "Date Created", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .dateCreated)
        }
        
        let sortByHeight = UIAlertAction(title: "Height", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .height)
        }
        
        let sortByWidth = UIAlertAction(title: "Width", style: .default) { [weak self] _ in
            self?.sortAlbums(by: .width)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        sortController.addAction(sortByName)
        sortController.addAction(sortByType)
        sortController.addAction(sortBySize)
        sortController.addAction(sortByDateModified)
        sortController.addAction(sortByDateCreated)
        sortController.addAction(sortByHeight)
        sortController.addAction(sortByWidth)
        sortController.addAction(cancelAction)
        
        present(sortController, animated: true, completion: nil)
    }
    
    enum SortOption {
        case name
        case type
        case size
        case dateModified
        case dateCreated
        case height
        case width
    }
    
    // Sorting function
    func sortAlbums(by option: SortOption) {
        var albumData = [(name: String, image: String, type: String, size: Int, dateModified: Date, dateCreated: Date, height: Int, width: Int)]()
        
        for i in 0..<albums.count {
            albumData.append((name: albums[i], image: albumImages[i], type: albumTypes[i], size: albumSizes[i], dateModified: albumDatesModified[i], dateCreated: albumDatesCreated[i], height: albumHeights[i], width: albumWidths[i]))
        }
        
        switch option {
        case .name:
            albumData.sort { $0.name < $1.name }
        case .type:
            albumData.sort { $0.type < $1.type }
        case .size:
            albumData.sort { $0.size < $1.size }
        case .dateModified:
            albumData.sort { $0.dateModified < $1.dateModified }
        case .dateCreated:
            albumData.sort { $0.dateCreated < $1.dateCreated }
        case .height:
            albumData.sort { $0.height < $1.height }
        case .width:
            albumData.sort { $0.width < $1.width }
        }
        
        albums = albumData.map { $0.name }
        albumImages = albumData.map { $0.image }
        albumTypes = albumData.map { $0.type }
        albumSizes = albumData.map { $0.size }
        albumDatesModified = albumData.map { $0.dateModified }
        albumDatesCreated = albumData.map { $0.dateCreated }
        albumHeights = albumData.map { $0.height }
        albumWidths = albumData.map { $0.width }
        
        collectionView.reloadData()
    }
    
    @IBAction func openDialog(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Create a new Album", message: "Please enter a name for the album", preferredStyle: .alert)
        
        alertController.addTextField { (textField) in
            let currentDate = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy" // Set the date format
            let dateString = dateFormatter.string(from: currentDate)
            
            textField.placeholder = dateString
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { [weak self, weak alertController] (_) in
            if let textField = alertController?.textFields?.first, let userInput = textField.text, !userInput.isEmpty {
                print("User input: \(userInput)")
                
                // Add new album to all arrays
                self?.albums.append(userInput)
                self?.albumImages.append("Loader") // Placeholder image
                self?.albumTypes.append("jpg") // Default file type
                self?.albumSizes.append(512) // Default size
                self?.albumDatesModified.append(Date()) // Default modified date
                self?.albumDatesCreated.append(Date()) // Default created date
                self?.albumHeights.append(500) // Default height
                self?.albumWidths.append(700) // Default width
                
                self?.collectionView.reloadData()
            }
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        
        present(alertController, animated: true, completion: nil)
    }
    let flickerLogo = UIImageView()
    let searchButton = UIButton()
    let registrationLabel = UILabel()
    let firstNameTextField = UITextField()
    let lastNameTextField = UITextField()
    let emailTextField = UITextField()
    let passwordTextField = UITextField()
    let confirmPasswordTextField = UITextField()
    let registerButton = UIButton()
    let orLabel = UILabel()
    let googleButton = UIButton()
    let facebookButton = UIButton()
    let appleButton = UIButton()
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return albums.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "albumCell", for: indexPath)
        
        // Access the UILabel using its tag
        if let label = cell.viewWithTag(1) as? UILabel {
            label.text = albums[indexPath.row] // Set album name
        }
        
        // Access the UIImageView using its tag
        if let imageView = cell.viewWithTag(2) as? UIImageView {
            imageView.image = UIImage(named: albumImages[indexPath.row]) // Set album image
        }
        
        return cell
    }
    

//    // MARK: - UICollectionView Delegate Method
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        // When a cell is clicked, open the Photos view controller in the tab bar
//        let selectedAlbum = albums[indexPath.row]
//        let selectedAlbumImages = albumImages[indexPath.row] // Or array of images based on album
//
//        // Assume that the "PhotosViewController" is part of the tab controller
//        if let tabBarController = self.tabBarController,
//            let photosVC = tabBarController.viewControllers?[1] as? PhotosViewController { // Assuming PhotosVC is the second tab
//            photosVC.albumName = selectedAlbum // Pass the selected album name
//            photosVC.albumImages = [selectedAlbumImages] // Pass images for that album (modify if needed)
//
//            tabBarController.selectedIndex = 1 // Switch to the Photos tab
//        }
//    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        // Set up UI elements
        flickerLogo.image = UIImage(named: "flicker_logo")
        flickerLogo.contentMode = .scaleAspectFit
        searchButton.setTitle("Search", for: .normal)
        searchButton.addTarget(self, action: #selector(searchButtonTapped), for: .touchUpInside)
        registrationLabel.text = "Registration"
        firstNameTextField.placeholder = "First Name"
        lastNameTextField.placeholder = "Last Name"
        emailTextField.placeholder = "Email Address"
        passwordTextField.placeholder = "Password"
        confirmPasswordTextField.placeholder = "Confirm Password"
        registerButton.setTitle("Register", for: .normal)
        registerButton.addTarget(self, action: #selector(registerButtonTapped), for: .touchUpInside)
        orLabel.text = "or Sign up with"
        googleButton.setImage(UIImage(named: "google_logo"), for: .normal)
        facebookButton.setImage(UIImage(named: "facebook_logo"), for: .normal)
        appleButton.setImage(UIImage(named: "apple_logo"), for: .normal)
        
        // Add UI elements to the view
        view.addSubview(flickerLogo)
        view.addSubview(searchButton)
        view.addSubview(registrationLabel)
        view.addSubview(firstNameTextField)
        view.addSubview(lastNameTextField)
        view.addSubview(emailTextField)
        view.addSubview(passwordTextField)
        view.addSubview(confirmPasswordTextField)
        view.addSubview(registerButton)
        view.addSubview(orLabel)
        view.addSubview(googleButton)
        view.addSubview(facebookButton)
        view.addSubview(appleButton)
        
        // Set constraints for UI elements (adjust as needed for iPhone XS Max)
        flickerLogo.translatesAutoresizingMaskIntoConstraints = false
        // ... add constraints for other elements
        
    }
    
    // Action methods
    @objc func searchButtonTapped() {
        // Implement search functionality
    }
    
    @objc func registerButtonTapped() {
        // Implement registration functionality
    }
}
